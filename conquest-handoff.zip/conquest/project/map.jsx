// map.jsx — Dark stylized world map placeholder for Conquest
// 9 regions, each is an organic landmass with internal territory markers.
// Drawn at 1600x900 viewBox; scales to fill its container.

const REGIONS = [
  {
    id: 'karamja', name: 'Karamja & Asgarnia', color: 'var(--r-karamja)', controller: 'blue',
    label: { x: 220, y: 130 },
    // Top-left landmass, irregular blob
    path: 'M 110 180 Q 90 130 140 105 Q 200 80 270 95 Q 340 105 380 145 Q 420 195 405 245 Q 390 295 340 305 Q 280 318 215 305 Q 155 295 120 260 Q 95 220 110 180 Z',
    territories: [
      { x: 170, y: 195, controller: 'blue' },
      { x: 240, y: 180, controller: 'blue' },
      { x: 300, y: 215, controller: 'blue' },
      { x: 220, y: 255, controller: 'blue' },
      { x: 320, y: 270, controller: '?' },
    ],
  },
  {
    id: 'fremennik', name: 'Fremennik', color: 'var(--r-fremennik)', controller: 'green',
    label: { x: 580, y: 110 },
    path: 'M 470 175 Q 460 125 510 100 Q 570 80 640 95 Q 710 110 740 155 Q 745 200 720 235 Q 690 270 630 280 Q 570 285 520 265 Q 475 240 470 175 Z',
    territories: [
      { x: 540, y: 175, controller: 'green' },
      { x: 610, y: 165, controller: 'green' },
      { x: 670, y: 200, controller: 'green' },
      { x: 580, y: 235, controller: 'green' },
    ],
  },
  {
    id: 'misthalin', name: 'Misthalin & Wilderness', color: 'var(--r-misthalin)', controller: 'blue',
    label: { x: 1110, y: 110 },
    path: 'M 950 175 Q 940 130 985 105 Q 1050 80 1130 90 Q 1210 100 1260 130 Q 1310 165 1310 215 Q 1305 270 1260 290 Q 1200 305 1130 305 Q 1055 300 1000 275 Q 955 245 950 175 Z',
    territories: [
      { x: 1020, y: 175, controller: 'blue' },
      { x: 1100, y: 165, controller: 'blue' },
      { x: 1180, y: 180, controller: 'blue' },
      { x: 1240, y: 215, controller: '?' },
      { x: 1170, y: 245, controller: 'blue' },
      { x: 1080, y: 250, controller: 'blue' },
    ],
  },
  {
    id: 'kandarin', name: 'Kandarin', color: 'var(--r-kandarin)', controller: 'blue',
    label: { x: 200, y: 480 },
    path: 'M 100 450 Q 80 405 130 380 Q 200 360 280 380 Q 340 400 350 450 Q 355 510 320 545 Q 270 570 200 565 Q 135 555 105 520 Q 90 485 100 450 Z',
    territories: [
      { x: 165, y: 445, controller: 'blue' },
      { x: 245, y: 435, controller: 'blue' },
      { x: 200, y: 495, controller: 'blue' },
      { x: 290, y: 510, controller: '?' },
    ],
  },
  {
    id: 'desert', name: 'Desert', color: 'var(--r-desert)', controller: 'green',
    label: { x: 600, y: 460 },
    path: 'M 480 430 Q 470 385 520 365 Q 590 350 660 365 Q 720 380 740 425 Q 750 470 720 510 Q 680 540 615 545 Q 545 545 505 520 Q 475 490 480 430 Z',
    territories: [
      { x: 550, y: 425, controller: 'green' },
      { x: 625, y: 420, controller: 'green' },
      { x: 690, y: 450, controller: 'green' },
      { x: 590, y: 490, controller: 'green' },
      { x: 660, y: 505, controller: 'green' },
    ],
  },
  {
    id: 'tirannwn', name: 'Tirannwn', color: 'var(--r-tirannwn)', controller: 'blue',
    label: { x: 1100, y: 470 },
    path: 'M 950 450 Q 935 400 985 380 Q 1060 365 1140 380 Q 1210 395 1230 440 Q 1240 490 1210 525 Q 1160 555 1090 555 Q 1020 550 980 525 Q 945 495 950 450 Z',
    territories: [
      { x: 1020, y: 440, controller: 'blue' },
      { x: 1100, y: 425, controller: 'blue' },
      { x: 1175, y: 450, controller: 'blue' },
      { x: 1130, y: 500, controller: 'blue' },
      { x: 1050, y: 510, controller: '?' },
    ],
  },
  {
    id: 'morytania', name: 'Morytania', color: 'var(--r-morytania)', controller: 'blue',
    label: { x: 230, y: 720 },
    path: 'M 110 700 Q 95 655 145 635 Q 215 615 290 635 Q 350 655 360 700 Q 365 745 330 775 Q 280 800 215 795 Q 150 790 120 760 Q 100 730 110 700 Z',
    territories: [
      { x: 175, y: 700, controller: 'blue' },
      { x: 250, y: 685, controller: 'blue' },
      { x: 305, y: 710, controller: 'blue' },
      { x: 220, y: 750, controller: 'blue' },
    ],
  },
  {
    id: 'kourend', name: 'Kourend', color: 'var(--r-kourend)', controller: 'blue',
    label: { x: 600, y: 715 },
    path: 'M 470 700 Q 460 650 510 630 Q 590 615 670 635 Q 730 655 745 700 Q 755 745 720 775 Q 670 800 605 795 Q 535 790 495 765 Q 465 735 470 700 Z',
    territories: [
      { x: 540, y: 695, controller: 'blue' },
      { x: 615, y: 680, controller: 'blue' },
      { x: 680, y: 705, controller: 'blue' },
      { x: 590, y: 745, controller: 'blue' },
      { x: 670, y: 755, controller: '?' },
    ],
  },
  {
    id: 'varlamore', name: 'Varlamore', color: 'var(--r-varlamore)', controller: 'green',
    label: { x: 1095, y: 720 },
    path: 'M 950 700 Q 935 650 990 630 Q 1065 615 1145 635 Q 1215 655 1230 700 Q 1240 745 1205 775 Q 1155 800 1085 795 Q 1015 790 980 765 Q 945 735 950 700 Z',
    territories: [
      { x: 1020, y: 695, controller: 'green' },
      { x: 1095, y: 685, controller: 'green' },
      { x: 1170, y: 705, controller: 'green' },
      { x: 1080, y: 745, controller: 'green' },
    ],
  },
];

// Connection lines between adjacent regions (subtle dashed lines)
const CONNECTIONS = [
  ['karamja', 'fremennik'],
  ['fremennik', 'misthalin'],
  ['karamja', 'kandarin'],
  ['kandarin', 'desert'],
  ['desert', 'tirannwn'],
  ['fremennik', 'desert'],
  ['misthalin', 'tirannwn'],
  ['kandarin', 'morytania'],
  ['desert', 'kourend'],
  ['tirannwn', 'varlamore'],
  ['morytania', 'kourend'],
  ['kourend', 'varlamore'],
];

const TEAM_FILL = {
  blue: '#4a8ef0',
  green: '#5fcf72',
  red: '#e85a4f',
};

function ConquestMap({ style = 'topo' }) {
  const W = 1400, H = 900;
  const regionById = Object.fromEntries(REGIONS.map(r => [r.id, r]));

  // Pre-compute centroids for connection lines (label position works well)
  const center = (id) => regionById[id].label;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" className="map-svg">
      <defs>
        {/* Background grid */}
        <pattern id="map-grid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.025)" strokeWidth="1" />
        </pattern>
        <pattern id="map-grid-major" width="160" height="160" patternUnits="userSpaceOnUse">
          <path d="M 160 0 L 0 0 0 160" fill="none" stroke="rgba(255,255,255,0.045)" strokeWidth="1" />
        </pattern>

        {/* Topographic stripe pattern (used inside regions) */}
        <pattern id="topo" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(35)">
          <line x1="0" y1="0" x2="0" y2="6" stroke="rgba(255,255,255,0.04)" strokeWidth="1" />
        </pattern>

        {/* Region land gradient — mimics user's #292423 land color */}
        <radialGradient id="land-grad" cx="50%" cy="40%" r="60%">
          <stop offset="0%" stopColor="#332b29" />
          <stop offset="100%" stopColor="#231e1d" />
        </radialGradient>

        {/* Glow filter */}
        <filter id="glow">
          <feGaussianBlur stdDeviation="3" />
        </filter>

        {/* Per-region color glow */}
        {REGIONS.map(r => (
          <radialGradient key={r.id} id={`grad-${r.id}`} cx="50%" cy="40%" r="70%">
            <stop offset="0%" stopColor={r.color} stopOpacity="0.18" />
            <stop offset="60%" stopColor={r.color} stopOpacity="0.05" />
            <stop offset="100%" stopColor={r.color} stopOpacity="0" />
          </radialGradient>
        ))}
      </defs>

      {/* Base layer — mid-blue ocean tone, dark land regions pop against it */}
      <rect x="0" y="0" width={W} height={H} fill="#15243f" />
      <rect x="0" y="0" width={W} height={H} fill="url(#map-grid)" />
      <rect x="0" y="0" width={W} height={H} fill="url(#map-grid-major)" />

      {/* Connection lines */}
      <g stroke="rgba(255,255,255,0.10)" strokeWidth="1" strokeDasharray="3 5" fill="none">
        {CONNECTIONS.map(([a, b], i) => {
          const A = center(a), B = center(b);
          return <line key={i} x1={A.x} y1={A.y} x2={B.x} y2={B.y} />;
        })}
      </g>

      {/* Regions: glow halo, then land, then border */}
      {REGIONS.map(r => (
        <g key={`halo-${r.id}`}>
          <path d={r.path} fill={`url(#grad-${r.id})`} />
        </g>
      ))}
      {REGIONS.map(r => (
        <g key={`land-${r.id}`}>
          <path d={r.path} fill="url(#land-grad)" />
          <path d={r.path} fill="url(#topo)" opacity="0.5" />
          <path d={r.path} fill="none" stroke={r.color} strokeWidth="2" strokeOpacity="0.85" />
          <path d={r.path} fill="none" stroke={r.color} strokeWidth="6" strokeOpacity="0.18" filter="url(#glow)" />
        </g>
      ))}

      {/* Territory markers */}
      {REGIONS.map(r => (
        <g key={`terr-${r.id}`}>
          {r.territories.map((t, i) => {
            const isUnknown = t.controller === '?';
            const fill = isUnknown ? '#1c1730' : TEAM_FILL[t.controller];
            return (
              <g key={i} transform={`translate(${t.x},${t.y})`}>
                <circle r="11" fill="rgba(0,0,0,0.5)" stroke={r.color} strokeWidth="1.5" strokeOpacity="0.5" />
                <circle r="8" fill={fill} stroke="#0a0813" strokeWidth="1.5" />
                {isUnknown && (
                  <text textAnchor="middle" y="3" fontSize="10" fontWeight="700" fill="#7a7088" fontFamily="Inter, sans-serif">?</text>
                )}
              </g>
            );
          })}
        </g>
      ))}

      {/* Region labels */}
      {REGIONS.map(r => {
        const cx = r.territories.reduce((s, t) => s + t.x, 0) / r.territories.length;
        // place label above region
        const minY = Math.min(...r.territories.map(t => t.y));
        const ly = minY - 60;
        return (
          <g key={`lbl-${r.id}`} transform={`translate(${cx}, ${ly})`}>
            <text
              textAnchor="middle"
              fontFamily="'Cinzel', serif"
              fontWeight="600"
              fontSize="13"
              letterSpacing="2.5"
              fill="rgba(255,255,255,0.78)"
              style={{ textTransform: 'uppercase' }}
            >
              {r.name.toUpperCase()}
            </text>
            <line x1="-22" y1="6" x2="22" y2="6" stroke={r.color} strokeWidth="1.5" strokeOpacity="0.7" />
          </g>
        );
      })}
    </svg>
  );
}

window.ConquestMap = ConquestMap;
window.REGIONS = REGIONS;
