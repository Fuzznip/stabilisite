// app.jsx — Conquest event page
// Note: window.ConquestMap and window.REGIONS come from map.jsx.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "layout": "rail",
  "showActivity": true,
  "showLabels": true,
  "accent": "#e63946"
} /*EDITMODE-END*/;

// ───────── Data ─────────
const TEAMS = [
{
  id: 'blue', rank: 1, name: 'Blue Phoenix',
  cls: 'blue',
  monogram: 'BP',
  score: 591,
  breakdown: [
  { label: '16 territories' },
  { label: '8 regions' }],

  color: '#5fa3e0'
},
{
  id: 'green', rank: 2, name: 'Green Giants',
  cls: 'green',
  monogram: 'GG',
  score: 322,
  breakdown: [
  { label: '15 territories' },
  { label: '3 regions' }],

  color: '#65cc6e'
},
{
  id: 'red', rank: 3, name: 'Red Dragons',
  cls: 'red',
  monogram: 'RD',
  score: 99,
  breakdown: [
  { label: '7 territories' },
  { label: '0 regions' }],

  color: '#e85a4f'
}];


// Region → controller mapping (from screenshot)
const REGION_INFO = [
{ id: 'karamja', name: 'Karamja & Asgarnia', color: 'var(--r-karamja)', colorHex: '#ef3f5b', team: 'blue', pts: 90, terr: { held: 6, total: 8 } },
{ id: 'fremennik', name: 'Fremennik', color: 'var(--r-fremennik)', colorHex: '#4caf50', team: 'green', pts: 70, terr: { held: 5, total: 7 } },
{ id: 'misthalin', name: 'Misthalin & Wilderness', color: 'var(--r-misthalin)', colorHex: '#ffd23f', team: 'blue', pts: 110, terr: { held: 7, total: 9 } },
{ id: 'kandarin', name: 'Kandarin', color: 'var(--r-kandarin)', colorHex: '#3b6df0', team: 'blue', pts: 60, terr: { held: 4, total: 6 } },
{ id: 'desert', name: 'Desert', color: 'var(--r-desert)', colorHex: '#ff8a3d', team: 'green', pts: 80, terr: { held: 6, total: 8 } },
{ id: 'tirannwn', name: 'Tirannwn', color: 'var(--r-tirannwn)', colorHex: '#8b5cf6', team: 'blue', pts: 50, terr: { held: 3, total: 5 } },
{ id: 'morytania', name: 'Morytania', color: 'var(--r-morytania)', colorHex: '#2dd4bf', team: 'blue', pts: 70, terr: { held: 5, total: 6 } },
{ id: 'kourend', name: 'Kourend', color: 'var(--r-kourend)', colorHex: '#e84db4', team: 'blue', pts: 65, terr: { held: 4, total: 7 } },
{ id: 'varlamore', name: 'Varlamore', color: 'var(--r-varlamore)', colorHex: '#b6e23a', team: 'green', pts: 55, terr: { held: 4, total: 6 } }];


const TEAM_LOOKUP = Object.fromEntries(TEAMS.map((t) => [t.id, t]));

const ACTIVITY = [
{ time: '2m', team: 'blue', type: 'capture', target: 'Falador', region: 'Karamja' },
{ time: '14m', team: 'green', type: 'task', target: 'Tempoross x10' },
{ time: '38m', team: 'blue', type: 'region', target: 'Misthalin & Wilderness' },
{ time: '1h', team: 'red', type: 'capture', target: "Mort'ton", region: 'Morytania' },
{ time: '2h', team: 'green', type: 'capture', target: 'Sophanem', region: 'Desert' },
{ time: '3h', team: 'blue', type: 'region', target: 'Karamja & Asgarnia' },
{ time: '4h', team: 'green', type: 'task', target: 'Wintertodt x25' }];


// ───────── UI bits ─────────
function StabilityMark() {
  return (
    <svg className="brand-mark" viewBox="0 0 22 22" fill="none">
      <path d="M11 1 L4 5 L4 17 L11 21 L18 17 L18 5 Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M11 5 L11 17" stroke="currentColor" strokeWidth="1.5" />
      <path d="M7 8 L11 6 L15 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M7 14 L11 16 L15 14" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>);

}

function Nav() {
  return (
    <nav className="nav">
      <a className="brand" href="#">
        <StabilityMark />
        STABILITY
      </a>
      <div className="nav-links">
        <a className="nav-link" href="#">Home</a>
        <a className="nav-link" href="#">Profile</a>
        <a className="nav-link" href="#">Leaderboards</a>
        <a className="nav-link active" href="#">Conquest</a>
      </div>
      <div className="nav-spacer" />
      <div className="nav-right">
        <button className="btn-apply">Apply</button>
        <div className="avatar-pill" />
      </div>
    </nav>);

}

function Hero() {
  return (
    <header className="hero">
      <div className="hero-left">
        <div className="meta-strip">
          <span className="countdown">ENDS IN <b>2D 14H 32M</b></span>
        </div>
        <h1>Conquest <span className="accent">Beta</span></h1>
      </div>
      <div className="hero-stats">
        <div className="hero-stat"><div className="v">147</div><div className="l">Players</div></div>
      </div>
    </header>);

}

// ───────── Map card ─────────
function MapCard() {
  return (
    <div className="map-card">
      <div className="map-overlay-bl">
        <span className="legend-item"><span className="swatch" style={{ background: '#4a8ef0' }} />Blue Phoenix</span>
        <span className="legend-item"><span className="swatch" style={{ background: '#5fcf72' }} />Green Giants</span>
        <span className="legend-item"><span className="swatch" style={{ background: '#e85a4f' }} />Red Dragons</span>
        <span className="legend-item"><span className="swatch" style={{ background: '#1c1730', border: '1px solid var(--text-4)' }} />Contested</span>
      </div>

      <window.ConquestMap />
    </div>);

}

// ───────── Standings panel ─────────
function StandingsPanel() {
  const max = Math.max(...TEAMS.map((t) => t.score));
  return (
    <aside className="panel">
      <div className="panel-head">
        <div className="panel-title">Standings</div>
        <div className="panel-sub">Updated 2m ago</div>
      </div>
      <div className="standings">
        {TEAMS.map((t) =>
        <div key={t.id} className={`team-row r${t.rank} t-${t.id}`}>
            <div className="rank">{t.rank}</div>
            <div className={`team-avatar ${t.cls}`}>{t.monogram}</div>
            <div className="team-info">
              <div className="team-name" style={{ fontFamily: "Inter" }}>{t.name}</div>
              <div className="team-meta">
                {t.breakdown.map((b, i) =>
              <span key={i}>{b.label}</span>
              )}
              </div>
            </div>
            <div className="team-score">
              <div className="pts">{t.score}</div>
              <div className="lbl">PTS</div>
            </div>
            <div className="score-bar"><i style={{ width: `${t.score / max * 100}%` }} /></div>
          </div>
        )}
      </div>
    </aside>);

}

function ActivityIcon({ type }) {
  if (type === 'task') {
    return (
      <svg className="act-icon" width="14" height="14" viewBox="0 0 14 14" fill="none">
        <circle cx="7" cy="7" r="5" stroke="currentColor" strokeWidth="1.4" />
        <path d="M4.5 7.2 L6.3 9 L9.5 5.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
      </svg>);

  }
  if (type === 'capture') {
    return (
      <svg className="act-icon" width="14" height="14" viewBox="0 0 14 14" fill="none">
        <path d="M3 1 V13" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
        <path d="M3 2 L11 2 L9 5 L11 8 L3 8 Z" fill="currentColor" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round" />
      </svg>);

  }
  // region — crown
  return (
    <svg className="act-icon" width="15" height="15" viewBox="0 0 15 15" fill="none">
      <path d="M2 5 L4 10 L11 10 L13 5 L10 7 L7.5 3.5 L5 7 Z" fill="currentColor" stroke="currentColor" strokeWidth="1" strokeLinejoin="round" />
      <path d="M3.5 12 L11.5 12" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>);

}

function ActivitySection() {
  return (
    <section className="activity-section">
      <div className="section-head">
        <div className="section-title">Recent Activity</div>
        <div className="section-subtitle" style={{ color: 'var(--accent-2)' }}>LIVE FEED</div>
      </div>
      <div className="activity-grid">
        {ACTIVITY.map((a, i) => {
          const team = TEAM_LOOKUP[a.team];
          return (
            <div className={`activity-row weight-${a.type}`} key={i}>
              <div className="activity-time">{a.time} ago</div>
              <div className="activity-team-chip">
                <div className={`team-avatar xs ${team.cls}`}>{team.monogram}</div>
                <span>{team.name}</span>
              </div>
              <div className="activity-text">
                <ActivityIcon type={a.type} />
                <span className="act-verb">{a.type === 'task' ? 'Completed' : a.type === 'capture' ? 'Captured' : 'Secured region'}</span>
                <span className="act-target">{a.target}</span>
                {a.region && a.type === 'capture' && <span className="act-region">{a.region}</span>}
              </div>
            </div>);

        })}
      </div>
    </section>);

}

// ───────── Region card ─────────
function RegionCard({ region }) {
  const team = TEAM_LOOKUP[region.team];
  const heldArr = Array.from({ length: region.terr.total }, (_, i) => i < region.terr.held);
  return (
    <div className="region-card" style={{ '--region-color': region.colorHex }}>
      <div className="region-name">{region.name}</div>
      <div className="region-team-row">
        <div className={`team-avatar sm ${team.cls}`}>{team.monogram}</div>
        <div className="region-team-name">{team.name}</div>
      </div>
      <div className="terr-pips">
        {heldArr.map((held, i) =>
        <span key={i} className={`terr-pip${held ? ' held t-' + region.team : ''}`} />
        )}
      </div>
    </div>);

}

function RegionsSection() {
  return (
    <section className="regions-section">
      <div className="section-head">
        <div className="section-title">Region Controllers</div>
      </div>
      <div className="regions-grid">
        {REGION_INFO.map((r) => <RegionCard key={r.id} region={r} />)}
      </div>
    </section>);

}

// ───────── App ─────────
function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply accent override
  React.useEffect(() => {
    document.documentElement.style.setProperty('--accent', t.accent);
    // Light-tone variant for accent-2
    document.documentElement.style.setProperty('--accent-2', t.accent);
  }, [t.accent]);

  return (
    <div className={`page layout-${t.layout}`}>
      <Nav />
      <main className="shell">
        <Hero />
        <div className="grid" style={t.layout === 'stacked' ? { gridTemplateColumns: 'minmax(0,1fr)' } : null}>
          <MapCard />
          <StandingsPanel />
        </div>
        <RegionsSection />
        <ActivitySection />
      </main>

      <TweaksPanel>
        <TweakSection label="Layout" />
        <TweakRadio
          label="Standings position"
          value={t.layout}
          options={[
          { value: 'rail', label: 'Side rail' },
          { value: 'stacked', label: 'Stacked' }]
          }
          onChange={(v) => setTweak('layout', v)} />
        
        <TweakSection label="Theme" />
        <TweakColor
          label="Accent"
          value={t.accent}
          options={['#e63946', '#d4a44a', '#4a8ef0', '#7c5dd6', '#5fcf72']}
          onChange={(v) => setTweak('accent', v)} />
        
      </TweaksPanel>
    </div>);

}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);